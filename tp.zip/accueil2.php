<?php
$titre="L'Accueil";
require_once 'header2.php';
?>

<h1>Bienvenue</h1>

<?php
require_once 'footer2.php';
?>