<?php
$titre="CV";
require_once 'header2.php';
?>

<h1>Ceci est le meilleur CV du monde</h1>

<?php
require_once 'footer2.php';
?>